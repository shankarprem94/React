import logo from './logo.svg';
import './App.css';
import Comp1 from "./c1/c1"
function App() {
  return (
    <div className="App">
      <Comp1 />
    </div>
  );
}

export default App;
