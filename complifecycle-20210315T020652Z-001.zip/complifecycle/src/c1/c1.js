import React    from "react";
import template from "./c1.jsx";
class c1 extends React.Component {
  constructor(){
    super()
    this.state={
      sno:100,
      uname:"scott",
      t1:"abcd"
    }
    console.log("Cons exec...")
  }
  static getDerivedStateFromProps(pr,st){
  console.log("get der state")
   st.uname="amith123456"
   return st;
  }
  shouldComponentUpdate(){
    console.log("update exec")
    return true;
  }
  funchange=({target})=>{
    this.state.t1=target.value
    this.setState({})
  }
  render() {
    console.log(this.state.uname)
    console.log("render")
    return template.call(this);
  }
  getSnapshotBeforeUpdate(p,st){
    console.log("snap shotexec")
    console.log(st)
    return true
  }
  componentDidMount(){
    console.log("Component created")
    var cont=document.getElementById("t1")
    cont.style.display="none"
  }
  componentDidUpdate(){
    console.log("Comp updated")
  }
}

export default c1;
