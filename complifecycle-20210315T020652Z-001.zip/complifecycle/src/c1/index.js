import c1 from "./c1";
export default c1;
