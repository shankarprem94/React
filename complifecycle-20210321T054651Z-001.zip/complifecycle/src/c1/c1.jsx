import "./c1.css";
import React from "react";

function template() {
  return (
    <div className="c-1">
      <h1>c1</h1>
      <input type="text" id="t1"  
      onChange={this.funchange.bind(this)} value={this.state.t1}/>
      <h2>{this.state.uname}</h2>
    </div>
  );
};

export default template;
